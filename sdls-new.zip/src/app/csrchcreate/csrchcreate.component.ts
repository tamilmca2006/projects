import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-csrchcreate',
  templateUrl: './csrchcreate.component.html',
  styleUrls: ['./csrchcreate.component.css']
})
export class CsrchcreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
