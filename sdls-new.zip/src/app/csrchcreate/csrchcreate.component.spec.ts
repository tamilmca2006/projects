import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CsrchcreateComponent } from './csrchcreate.component';

describe('CsrchcreateComponent', () => {
  let component: CsrchcreateComponent;
  let fixture: ComponentFixture<CsrchcreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CsrchcreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CsrchcreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
