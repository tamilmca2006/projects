import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmuser',
  templateUrl: './cmuser.component.html',
  styleUrls: ['./cmuser.component.css']
})
export class CmuserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
