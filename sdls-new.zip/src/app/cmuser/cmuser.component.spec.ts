import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmuserComponent } from './cmuser.component';

describe('CmuserComponent', () => {
  let component: CmuserComponent;
  let fixture: ComponentFixture<CmuserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmuserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
