import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lrcreate',
  templateUrl: './lrcreate.component.html',
  styleUrls: ['./lrcreate.component.css']
})
export class LrcreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
