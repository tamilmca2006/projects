import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LrcreateComponent } from './lrcreate.component';

describe('LrcreateComponent', () => {
  let component: LrcreateComponent;
  let fixture: ComponentFixture<LrcreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LrcreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LrcreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
