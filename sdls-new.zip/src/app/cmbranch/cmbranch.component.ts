import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmbranch',
  templateUrl: './cmbranch.component.html',
  styleUrls: ['./cmbranch.component.css']
})
export class CmbranchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
