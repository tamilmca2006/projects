import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmbranchComponent } from './cmbranch.component';

describe('CmbranchComponent', () => {
  let component: CmbranchComponent;
  let fixture: ComponentFixture<CmbranchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmbranchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmbranchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
