﻿import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login';
import { LrcreateComponent } from './lrcreate';
import { CmbranchComponent } from './cmbranch/cmbranch.component';
import { CmuserComponent } from './cmuser/cmuser.component';
import { CsrchcreateComponent } from './csrchcreate/csrchcreate.component';
import { AuthGuard } from './_guards';

const appRoutes: Routes = [
    { path: '', component: LoginComponent},
    { path: 'login', component: LoginComponent },
    { path: 'lrcreate', component: LrcreateComponent},
    { path: 'cmbranch', component: CmbranchComponent},
    { path: 'cmuser', component: CmuserComponent},
    { path: 'csrchcreate', component: CsrchcreateComponent},
    
    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const routing = RouterModule.forRoot(appRoutes);